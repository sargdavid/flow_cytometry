################   Functions for DNAMR package  ###############################
############# copyright (C) 1997-2004  Dhammika Amaratunga and Javier Cabrera.
###############################################################################
# narm toarray rmean.na rmean cmean rvar  rmedian rmedian.na
# cmed csort rsort cnormalize concor MRimage concor.map 
# MRpairs prep.summary rave rmest impute.knn rsdrsp rssp rttest 
# mad  cv  sam.constant sam ct plms 
############################################################################
## This function replaces NA's by F or zero
narm <-  function(x) {x[is.na(x)] <- F; x}
## Converts a numeric data.frame to an array
toarray <- function(x) array(unlist(x) , dim(x), dimnames(x))
### This is th ecode for matapply and the corresponding functions. matapply is a version 
### of apply that uses matrix multiplication for most standard functions.
fastapply= function(x,margin,fun,...) {
   zz = match.call()
   ff=as.character(zz$fun)
  switch(ff,
         mean = if(margin==1) rmean(x,...) else if(margin==2)cmean(x,...),
         median = if(margin==1) rmedian(x,...) else if(margin==2)cmedian(x,...),
         var = if(margin==1) rvar(x,...) else if(margin==2) cvar(x,...),
         sd = if(margin==1) rsd(x,...) else if(margin==2) csd(x,...),
         mse = if(margin==1) rmse(x,...) else if(margin==2)cmse(x,...),
         mad = if(margin==1) rmad(x,...) else if(margin==2)cmad(x,...),
         mest = if(margin==1) rmest(x,...) else if(margin==2)rmest(t(x),...),
         cv = if(margin==1) rcv(x,...) else if(margin==2)ccv(x,...),
         sort = if(margin==1) rsort(x,...) else if(margin==2)csort(x,...),
         sum = if(margin==1) rsum(x,...) else if(margin==2)csum(x,...),
         max = if(margin==1) rmax(x,...) else if(margin==2)cmax(x,...),
         min = if(margin==1) rmin(x,...) else if(margin==2)cmin(x,...),
         range= if(margin==1) rmax(x,...)-rmin(x,...) else if(margin==2)cmax(x,...)-cmin(x,...),
         t.test = if(margin==1) rttest(x,...) else if(margin==2)rttest(t(x),...),
         ttest = if(margin==1) rttest(x,...) else if(margin==2)rttest(t(x),...),
         ct  =  if(margin==1) ct(x,...) else if(margin==2)ct(t(x),...),
         F.test = if(margin==1) rF(x,...) else if(margin==2)rttest(t(x),...),
         cF = if(margin==1) cF(x,...) else if(margin==2)cF(t(x),...),
         apply(x, margin,fun,...)
  )
}

rsum <- function(x,na.rm=F) 
  if(!na.rm)  c(x%*%rep(1,ncol(x))) else rsum.na(x) 
csum <- function(x,na.rm=F) 
  if(!na.rm)  c(rep(1,nrow(x))%*%x)  else rsum.na(t(x)) 
rmean <- function(x,n=ncol(x),na.rm=F) 
  if(!na.rm)  c(x%*%rep(1,n))/n else rmean.na(x)
cmean <- function(x,n=nrow(x),na.rm=F) 
  if(!na.rm) c(rep(1,n)%*%x)/n else rmean.na(t(x))
rmax = function(x,n=ncol(x), na.rm=F) 
  eval(parse(text=paste("pmax(",paste("x[,",1:n,"]",collapse=",",sep=""),",na.rm=na.rm)",collapse="")))
cmax = function(x,n=nrow(x), na.rm=F) 
  eval(parse(text=paste("pmax(",paste("x[",1:n,",]",collapse=",",sep=""),",na.rm=na.rm)",collapse="")))
rmin = function(x,n=ncol(x), na.rm=F) 
  eval(parse(text=paste("pmin(",paste("x[,",1:n,"]",collapse=",",sep=""),",na.rm=na.rm)",collapse="")))
cmin = function(x,n=nrow(x), na.rm=F) 
  eval(parse(text=paste("pmin(",paste("x[",1:n,",]",collapse=",",sep=""),",na.rm=na.rm)",collapse="")))


# The new rmean function that handles missing values 
rmean.na <- function(x,n=ncol(x),na.rm=T) {
  ik <- rep(1,n)
  if(na.rm) {
    i <- is.na(x)
    ii <- c((!i)%*%ik)
    x[i ] <- 0
    return( c(x%*%ik)/ii )
  } else   return( c(x%*%ik)/n) 
}
rsum.na <- function(x,n=ncol(x),na.rm=T) {
  ik <- rep(1,n)
  if(na.rm) {
    x[is.na(x)] <- 0
    c(x%*%ik)
  } else  c(x%*%ik) 
}
# Calculate the variance
rvar  <- function(x,n=ncol(x),na.rm=F) rsum((x-rmean(x,n,na.rm))^2,na.rm)/(n-1)
cvar  <- function(x,n=nrow(x),na.rm=F) rvar(t(x),n,na.rm)

rsd  <- function(x,n=ncol(x),na.rm=F) sqrt(rsum((x-rmean(x,n,na.rm))^2,na.rm)/(n-1))
csd  <- function(x,n=nrow(x),na.rm=F) sqrt(rvar(t(x),n,na.rm))

rmse <- function(x, gr,na.rm=T) {
  x = x[,sort.list(gr)]
  gr = sort(gr)
  ngr=length(unique(gr))
  xm <- if(na.rm==T) rmean(x) else rmean(x,F)
  j= rep(c(diag(rep(1,ngr))),rep(table(gr),ngr))
  j = matrix(j,byrow=F,ncol=ngr)
  
  SSB<- rsum((cmat(x, gr,na.rm) - xm)^2 * ((!is.na(x))%*%j),na.rm)
  SST<- rsum((x - xm)^2,na.rm)
  (SST-SSB)/(rsum(!is.na(x))-1)
}
cmse <- function(x, gr) rmse(t(x),gr)
  
##
##
rmedian <-  function(x,na.rm=F) 
  if(!na.rm) cmed(t(x)) else rmedian.na(x)
cmedian <-  function(x,na.rm=F) 
  if(!na.rm) cmed(x) else rmedian.na(t(x))
##

rmedian.na <-  function(x) {
 n <- nrow(x)
 p <- ncol(x)
 xm <- rep(NA, n)
 nax <- is.na(x)
 nai <- c(nax %*% rep(1,p))
 x <- t(x)
 for(i in unique(nai)) {
    j <- nai ==i
    xi <- c(x[,j])
    xi <- array(xi[!is.na(xi)],c(p-i,sum(j)))
    xm[j] <- cmed(xi)
} 
xm
}

##
## cmed cat cnormalize
cmed <-  function(x) { 
 n  <- nrow(x)
 p  <- ncol(x)
 rx <- range(x)
 z  <- (x - rx[1])/(rx[2]-rx[1])*0.99
 k <- rep(1:p,rep(n,p))
 z  <- sort( z + k)
 dim(z) <- dim(x)
 z0 <- if( 2*(n%/%2) == n) (z[n/2,] + z[n/2+1,])/2 else z[(n+1)/2,]
 (z0-1:p)/0.99*(rx[2]-rx[1])+rx[1]
}
#### 
######
#csort <-  function(x) { 
# n  <- nrow(x)
# p  <- ncol(x)
# rx <- range(x)
# z  <- (x - rx[1])/(rx[2]-rx[1])*0.99
# k <- rep(1:p,rep(n,p))
# z  <- sort( z + k)-k
# dim(z) <- dim(x)
# z/0.99*(rx[2]-rx[1])+rx[1]
#}

csort <-  function(x,na.rm=F) {
  cst = function(x) { 
    n  <- nrow(x)
    p  <- ncol(x)
    rx <- range(x)
    z  <- (x - rx[1])/(rx[2]-rx[1])*0.99
    k <- rep(1:p,rep(n,p))
    z  <- x[sort.list( z + k)]
    dim(z) <- dim(x)
    z
  }
  if(na.rm) {
  n <- nrow(x)
  p <- ncol(x)
  xs <- x+NA
  nai <- csum(is.na(x))
  for(i in unique(nai)) {
    j <- nai ==i
    xi <- c(x[,j])
    xi <- array(xi[!is.na(xi)],c(n-i,sum(j)))
    xs[1:(n-i),j] <- cst(xi)
  } 
  xs 
  } else cst(x)
}
rsort  <- function(x,na.rm=F) t(csort(t(x),na.rm))
rmad <- function(x,constant = 1.4826,na.rm=F) 
  constant*rmedian(abs(x-rmedian(x,na.rm)),na.rm)
cmad <- function(x,constant = 1.4826,na.rm=F) rmad(t(x),constant,na.rm)

rcv  <- function(x,n=ncol(x),na.rm=F) {
  num = rsd(x,n,na.rm)
  den = rmean(x,n,na.rm)
  den[num ==0] = 1
  num/den
}
ccv  <- function(x,n=nrow(x),na.rm=F) rcv(t(x),n,na.rm)

## 908 - 5808631
##
#cat <- function(x) { 
#cat(dimnames(x)[[,2]], sep=" ")
#cat("\n")
#for( i in 1:10) { cat( x[i,], sep=" "); cat("\n")}
#}
##
##
############ Simple Quantile Normalization ######
##
cnormalize <- function (x,method= c("quantile","FY","zscores")[1]) {
# x is an array of numbers.
# quantile = does quantile normalization of the arrays
# FY = does Fisher-Yates normalization
# zscores= does zscores
if(!is.matrix(x))x= as.matrix(x)
if(method=="zscores") t((t(x) -cmean(x))/csd(x)) else{
xm <- apply(x, 2, sort)
xxm <- if(method=="FY") rmedian.na(xm) else qnorm((1:nrow(x))/(nrow(x)+1))         
xr <- c(apply(x, 2, rank))
array(approx(1:nrow(x), xxm, xr)$y, dim(x), dimnames(x))
}  }
# cnormalize <- function(x,method=
# c("quantile","Fisher-Yates","zscores")[1]) {
# # This function performs a quantile normalization on a GSM X
# # Missing values are not allowed
#         xm <- apply(x,2,sort)
#         xr <- apply(x,2,rank)
#     if((u<- substring(method,1))=="F")  qnorm(xr/(p+1)) 
#      else if (u=="q")  {xxm <- rmedian.na(xm)
#         array( approx(1:nrow(x),xxm,xr)$y, dim(x),dimnames(x))}
#     else if(u =="z") t((t(x) -cmean(x))/csd(x))
#   }
##
##
####################################################################
## Concordance Correlation and related functions
##
concor <- function(X,Y) {
# Calculates the concordance correlation matrix
# X:  Matrix or vector
# Y:  Optional vector or matrix
  if (!missing(Y)) X <- cbind(X,Y)
  d <- ncol(X)
  n <- nrow(X)
  tx <- t(X)
  nam <- names(data.frame(X))
  xm <-  rmean(tx)
  xv <- rvar (tx) 
  xsd <- sqrt(xv) 
  tx <- (tx -xm)
  z <- array(1,c(d,d),dimnames=list(nam,nam))
  for(i in 2:d) for ( j in 1:(i-1) )
    z[i,j] <- 2*sum(tx[i,]*tx[j,])/n / (xv[i]+xv[j] + (xm[i]-xm[j])^2 ) 
  z + t(z) - 1
}
####################################################################
####  
MRimage <-  function(X,gem=F) {
# Function to graph a concordance map. 
# gem= F (default)  X= Correlation matrix
# gem= T   X= Gene expression matrix (or any data matrix)
    if (gem | nrow(X)>ncol(X)) X <- concor(X) else if(ncol(X)>nrow(X)) X = concor(t(X))
# SAVE OLD GRAPHICS CONFIGURATION
#    opar <- par(mar=c(5,4,3,2),mgp=c(1.5,0.5,0))
# SETUP THE LAYOUT
    mm <- array(c(1,2),dim=2)
    nf <- layout(mm,4,c(5,1),TRUE) 
    r <- range(X); 
    n <- nrow(X)
    xx<- 1:n
    U <- seq(length=100,from=r[1],to=r[2])
# DRAW IMAGE (OR INSERT HERE YOUR IMAGE CODE)
    par(mar=c(1,2,5,2),mgp=c(1.5,0.7,0))
    image(x=xx,y=xx,z=t(X[n:1,]),axes=F,xlab="",ylab="")
    box()
    nn= names(data.frame(X))
axis(3,labels=nn,at=xx) 
axis(2,labels=rev(nn),at=xx)
 
# DRAW THE SCALE
    par(mar=c(3,2,1,2),mgp=c(1.5,0.7,0))
    image(x=U,z=array(U,c(100,1)),xlab="" ,axes=F)
    box();axis(1) 
# RESTORE OLD GRAPHICS CONFIGURATION
    par(mfrow=c(1,1))# par(opar)    
}
##############################################
concor.map <- function(x,y) if(missing(y)) MRimage(concor(x)) else MRimage(concor(x,y))
##
MRpairs <- function(X) 
## Graph the scatterplot matrix of X with a smoothing curve
##  
pairs(X,panel= function(x,y) { 
		points(x,y,pch='.');
 		abline(0,1,col=2,lwd=1.5);
		lines(lowess(x,y,f=0.2),col=3,lwd=1.5)
		}
	)
#####################################################################
##        Pre-procesing transformation:                            ##
##        Use this code to find k for the transformation           ##
##                     log( X - k)                                 ##
##        pre.summary rave rmest 					 ##
#####################################################################
##
prep.summary <- function(x,k=0,npages=1 ) { # Summary about transformations
        p <- ncol(x)
        x <- data.frame(x)
        pp = ceiling(p/npages)
         par(mfcol=c(4,pp))
        par(mar=c(3,1,3,1))
        nam <- names(x)
        nam1 <- paste ("Log(",nam,")",sep="")
        lx <- log(x-k)
        for( i in 1:p) {
          hist(x[[i]],main=nam[i])
          qqnorm(x[[i]],main=nam[i])
          hist(lx[[i]],main=nam1[i])
          qqnorm(lx[[i]],main=nam1[i])
        }
        invisible()  ##
} 
##
##
rave <- function(x)  { 
# The function is given below. The input "x" is a GxR matrix of intensities with 
# G genes along the rows and R replicates (e.g., 4 similar panels) along the 
# columns. The output is a G-vector of robust averages. 
    library(modreg)
    x = matrix( as.numeric( as.matrix(x) ), nrow=nrow(x) ) 
    if(ncol(x)==1) return(c(x))
    mx <- rmedian.na(x)
    ssx <- apply(abs(x-mx),1,mean,na.rm=T) 
    mx2 <- rep(mx, ncol(x)) 
    xx <- c(x) 
    jj <- is.na(mx) 
    ii <- is.na(mx2) | is.na(xx) 
    sx <- rep(NA, length(mx)) 
    sx[!jj] <- predict(loess(abs(xx[!ii] - mx2[!ii]) ~ mx2[!ii]), mx[!jj])
    sx <- pmax(sx,ssx)
    rmest( x, mu=mx,s=sx) 
}
#########################################################################
##
rmest <- function(y, mu, s, k, method = "bisquare", iter = 1) {
# This function calculates the M-estimator of location for the 
# rows of a matrix "y".  
# mu and s are the initial estimates of location and scale. By default 
# they are set to 0 and 1.
# method: "bisquare" m-estimator as default and "huber" m-estimator is optional.
# k = tuning parameter. As a default is 5 for the "bisquare" method and 2 for
# huber's method.
#  iter:  is the number of iterations. Iter =1 is a one step m-estimator. 
    method <- substring(method, 1, 1)
    if(missing(k))
        if(method == "h") k <- 2
        else k <- 5
    if(missing(mu))
        mu <- apply(y, 1, median, na.rm = T)
    if(missing(s))
        s <- apply(y, 1, mad, na.rm = T) 
    y1 <- c(y)
    kk <- dim(y)
    id <- rep(1:kk[1], kk[2])
    n <- length(y)
    s[s <= 0] <- min(s[s > 0], na.rm = T)
    s0 <- rep(s, kk[2])
    for(i in 1:iter) {
        mu0 <- rep(mu, kk[2])
        if(method == "h") {
            mu0 <- rep(mu, kk[2])
            yy <- pmin(pmax(mu0 - k * s0, y1), mu0 + k * s0)
            mu1 <- rmean(array(yy, dim = kk))
        }
        else {
            yy1 <- (y1 - mu0)/s0
            w <- (k^2 - yy1^2)^2
            w[is.na(w)] <- 0
            w[abs(yy1) > k] <- 0
            w <- array(w, dim = kk)
            w <- w/c(w %*% rep(1, kk[2]))
            y[is.na(y)] <- 0
            mu1 <- c((y * w) %*% rep(1, kk[2]))
        }
        mu <- mu1
    }
    mu
}

##########################################################
##   Imputation of nearest neighbors by imputation  ######
##   impute.knn
##########################################################
## Function to fix missing values by the k nearest neighbors method 
# Please make sure the argument x is an array.
impute.knn <- function(x, k = 2, min.row=3, min.col=k) { 
# Arguments:
#  x : array only. Dataframe is not allowed.
#  k : Number of nearest neighbors to estimate missing obs.
#  min.row: The minimum number of non missing values in a row. If there 
#     are fewer, then the row is discarded.
#  min.col: The minimum number of non missing values in a sample. If there 
#     are fewer, then the sample is discarded. As a deafult is set to k.
#
library(class)
 n <- nrow(x); m <- ncol(x)
   ina <- is.na(x)
   mna <- c(rep(1,n)%*%(!ina))
   if(any(mna < min.col)) {
       warning(paste("Column-s ", paste((1:m)[mna<min.col],collapse=",")," were deleted because they have fewer than ",min.col," values.",sep=""))
       x <- x[,mna >= min.col] 
       m <- ncol(x)
     ina <- ina[,mna >= min.col] 
   } 
   nna <- c((!ina)%*% rep(1,m))
   if(any(nna < min.row)) {
       warning(paste("Row-s ", paste((1:n)[nna<min.row],sep=",")," were deleted becuase they have fewer than ",min.row," values.",sep=""))
       x <- x[nna >= min.row,]
       n <- nrow(x)
       ina <- ina[nna >= min.row,];nna <- nna[nna >= min.row]  
   } 
   x1 <- x
   nk <- (1:n)[nna<m]
   for(i in nk) {
       ii <- ina[i,]
       iina <- c(ina[,!ii]%*%rep(1,mm <-sum(!ii)))
       dd <-0
       for(w in 1:10) {
           jj <- iina <=dd
           ina[jj,ii,drop=F]
           if( all( c(rep(1,sum(jj))%*%!ina[jj,ii,drop=F]) >=k)) break
           else dd <- dd+1
       }
       xx <- x[iina <=dd,,drop=F]
       dx <- rmean(t((t(xx[,!ii]) -x[i,!ii])^2))
       est <- apply( xx[sort.list(dx),ii,drop=F],2,function(x)mean(x[!is.na(x)][1:k])) 
       x1[i,ii] <- est
   }
   x1
}

################################  Conditional T code ########################
#
# This function calculates the Conditional-t cutoffs for the t statistics 
# for comparing the differential gene expressions between two groups
# of samples for a set of G genes (one per gene). Optionally it will produce
# a graph of the observed gene t-statistics Vs the gene standard deviations and
# the envelop for the corresponding quantiles.
# 
#################################   ARGUMENTS FOR ct #####################
#  
# xx : Array of gene expressions for G genes by k samples for the 
#      samples of Treatment 1 (could be the control group) 
# yy : Array of gene expressions for G genes by k samples for the 
#      samples of Treatment 2 (could be the control group). 
#      Notice that we assume that ncol(xx) == ncol(yy) 
# qi : A number or a vector specifying the percentiles for each of the 
#      envelopes that will be computed. default is qi = c(.95,.99)
# bzs: Block size for the simulations.
# plotenv: Produce a graph with the envelop.
############################################################################# 
## Example: 
#           x = matrix(rnorm(4000),1000,4)
#          mu= rep(c(2,0),c(100,900))
#           y = matrix(rnorm(4000),1000,4) + mu 
#           z.ct = ct(x,y,plotenv = T)
#           table(abs(z.ct[,1])> z.ct[,2],mu)
## Compare this with the two-sample t-test 
#           table( abs(z.ct[,1]) >qt(0.975,6) ,mu)
## calculate p-values
#           z.ct= ct(x,y,qi=c(0.5,0.9,0.95,0.99,0.999))
#           pval = ctpval(z.ct)
#
################  Conditional T and mu. Use this code with caution since
################  still needs lots of testing########################
##
## This function calculates the Conditional-t cutoffs for the t statistics 
## for comparing the differential gene expressions between two groups
## of samples for a set of G genes (one per gene). Optionally it will produce
## a graph of the observed gene t-statistics Vs the gene standard deviations and
## the envelop for the corresponding quantiles.
## 
##################################   ARGUMENTS FOR ctcmu #################
##  
## xx : Array of gene expressions for G genes by k samples for the 
##      samples of Treatment 1 (could be the control group) 
## yy : Array of gene expressions for G genes by k samples for the 
##      samples of Treatment 2 (could be the control group). 
##      Notice that we assume that ncol(xx) == ncol(yy) 
## qi : A number or a vector specifying the percentiles for each of the 
##      envelopes that will be computed. default is qi = c(.95,0.99)
## bzs: Block size for the simulations.
##
############################################################################## 
### Example conditioning on m
## Generate the data
#           n= 4000; p=4; resmu=resmu1=NULL
#           mu0 = exp(sample(seq(1,2.9,length=n)))+ rchisq(n,3)
#                                  #           sig0 = sqrt(mu0* rchisq(n,3))/20
#           mu= rep(c(12,0),c(200,n-200))
#           sig0  = (mu0/2+mu/2)
#           x = matrix(rnorm(p*n),n,p)*sig0+mu0
#           
#           y = matrix(rnorm(p*n),n,p)*sig0+mu0+mu 
## Conditioning on mu 
#           z.ctcmu = ctcmu(x,y)
#           mupval = ctpval(z.ctcmu)
## Compare it with unconditional
#           z.ct = ct(x,y)
#           tpval = ctpval(z.ct)
#
## Evaluate comparison: CTCMU should be better
#           table(mu[mupval <= 0.05]),table( mu[tpval <= 0.05]) 
#           table(mu[sort.list(tpval)[1:100]])
#           table(mu[sort.list(mupval)[1:100]])
#
############################################################################
ct = function (x, y, qi = c(0.5,0.9,0.95,0.99,.999), bsz = 200, plotenv=F,tol=10^(-10),pval=T)
{
   x <- toarray(x)
   if((nc<-ncol(x))==length(y) & length(zz<-unique(z<-y))==2){
    y=x[,z!=zz[1]]
    x=x[,z==zz[1]]
  } else y <- toarray(y)
    xsp <- rsd(cbind(x, y))
    isp = !is.na(xsp) & xsp > tol
    xx = x[isp,]
    yy = y[isp,]
    xsp =rsp(xx, yy)
    nr <- nrow(xx)
    dd <- dim(xx)
    dy <- dim(yy)
    xt <- rttest(xx, yy)[,1]
#
xspp <- xsp
u = cbind(xx[abs(xt)< 1,],yy[abs(xt)< 1,])
u = (u-rmean(u))/rsd(u)
for(l in 1:20) {
xsp0 <- xspp
xsps <- sample(xsp0, replace= F)
x1 <- x2 <- NULL
for (i in 1:10) {
        x1 <- rbind(x1, array(sample(u), dd) * xsps)
        x2 <- rbind(x2, array(sample(u), dy) * xsps)
    }
xsp1 <-rsp(x1, x2)
m = ncol(x1)
x1 <- (x1 - rmean(x1))/xsp1/sqrt((m-1)/m)
y1 <- (x2 - rmean(x2))/xsp1/sqrt((m-1)/m)

xsps <- sort(xsp1)[(1:nr) * 10 - 5]
sxps <- sort(xsp)
sxps0 <- sort(xsp0)
    # this is the inverse computation.   Ft F^(-1) Fh
xspp <- smdecreasing(smooth.spline(xsps, sxps), sxps0, F)
}
#
    xsps <- sample(xspp, replace= F)
    xnn1 <- xnn2 <- NULL
    for (i in 2:(bsz%/%50)) {
        xnn1 <- rbind(xnn1, array(sample(u), dim(xx)) * xsps)
        xnn2 <- rbind(xnn2, array(sample(u), dim(yy)) * xsps)
    }
    xt1 <- rttest(xnn1, xnn2)[,1]
    xsp1 <-rsp(xnn1, xnn2)
    out = renv(xsp1,abs(xt1),xsp,abs(xt),lqi=NULL,hqi=qi,type="none",sym=F,logtran=T,plot=plotenv)
    #if(all(isp)& !pval) return(out) 
        res = array(0,c(nrow(x),ncol(out)), dimnames=list(rownames(x),colnames(out)))
        res[isp,] = out
   if(pval) cbind(pv=ctpval(res),res) else res
}

wcomp <- function(x,gr,cons=0.99,method="ct") {
    ### Rows of x are Genes, Columns of x are samples  #####
    ### "ct" or "t" or "cF" or "F" or "cor"
  x = toarray(x)
  
  if(method !="cor") y1=as.numeric(factor(gr))
    if (method=="ct") u=ct(x[,y1==1],x[,y1==2])[,1]
    else if(method=="t") u=rttest(x[,y1==1],x[,y1==2])[,3]
    else if(method=="cF") u=cF(x,gr)[,1]
    else if(method=="F") u=rF(x,gr)[,2]
    else if(method=="cor") u=sapply(summary(aov(t(x)~gr)),function(z)z[1,5])
            u=wfda(u,cons)
    u / sum(u)*length(u)
}



ct2 =function (x, y, qi = c(0.2,0.4,0.6,0.8,0.9,0.95,0.99,0.999,.9999), bsz = 50, plotenv = F)
{
  ### Raws of x are Genes, Columns of x are samples  #####
  require(quantreg);require(DNAMR)
  x <- toarray(x)
  if(is.null(dim(y))) {
    ii =  (y == sort(unique(y))[1])
    y = x[,ii]
    x = x[,!ii]
  } else   y  =  toarray(y)
  xsp <- rsd(cbind(x, y))
  isp = !is.na(xsp)
  xx = x[isp, ]
  yy = y[isp, ]
  xsp = rsp(xx, yy)
  nr <- nrow(xx)
  dd <- dim(xx)
  dy <- dim(yy)
  xt <- rttest(xx, yy)[,1]
  xspp <- xsp
  u = cbind(xx[abs(xt) < 1, ], yy[abs(xt) < 1, ])
  u = (u - rmean(u))/rsd(u)
  sxps <- sort(xsp)
  for (l in 1:5) {
    xsp0 <- xspp
    xsps <- sample(xsp0, replace= F)
    xsp1 <- NULL
    for(i in 1:5) {
      x1 <- array(sample(u,2*dd[1]*dd[2],replace=T), c(2*dd[1],dd[2])) * rep(xsps,2)
      x2 <- array(sample(u,2*dy[1]*dy[2],replace=T), c(2*dy[1],dy[2])) * rep(xsps,2)
      xsp1 <- c( xsp1,rsp(x1, x2)) }
    xsps <- sort(xsp1)[(1:nr) * 10 - 5]
    sxps0 = sort(xsp0)
    xspp = smdecreasing(smooth.spline(xsps,sxps),sxps0,F)
  }
  xsps <- sample(xspp, replace= F)
  pnnn=prod(dd);pnny=prod(dy); xt1<-xsp1<-NULL
  #   for (i in 2:(bsz%/%50)) {
  xnn1 <- array(sample(u,pnnn,replace=T), dd) * xsps
  xnn2 <- array(sample(u,pnny,replace=T), dy) * xsps
  xt1 <- c(xt1,rttest(xnn1, xnn2)[,1])
  xsp1 <- c(xsp1,rsp(xnn1, xnn2))
  #   }
  
  #        xnn1 <- array(sample(u,pnnn,replace=T), nnn) * xsps
  #        xnn2 <- array(sample(u,pnnn,replace=T), nnn) * xsps
  
  l1 = log(xsp1[i <- sample(length(xsp1),min(length(xsp1),10000))])
  l2 = log(abs(xt1[i]))
  ccc = rq(l2~l1+I(l1^2)+I(l1^3),qi)$coef
  m1 = log(xsp); m2 = log(abs(xt))
  out = cbind(abs(xt),exp(cbind(1,m1,m1^2,m1^3)%*%ccc),xsp)
  dimnames(out) = list(rownames(xx),c("T", paste("Curve",qi, sep = ""),"Sp"))
  if (all(isp)) return(ctpval(out))
  res = array(0, c(nrow(x), ncol(out)), dimnames = list(rownames(x),
                                                        colnames(out)))
  res[isp, ] = out
  ctpval(res)
}


cF= function(x, gr, qi = c(.25,.5,0.9, 0.975, 0.99, 0.999),topgn=nrow(x),flag=F)
{
  library(DNAMR)
  dg=7; mm=100
  tk <- c(table(gr))
  x <- toarray(x)
  nr <- nrow(x)
  xf <- rF(x, gr)[,1]
  xmse <- sqrt(c(rmse(x,gr)))######
  sgr<-sort(gr)
  xmses <- sample(xmse, replace= F)
  x1<-c()
  for(i in unique(sgr))
    x1<-cbind(x1,x[,gr==i]-rmean(as.matrix(x[,gr==i])))
  x1 <- x1/xmse
  #browser()
  xnn2<-c()
  xf1<-c()
  xmse1<-c()
  for (j in 1:10) {
    xnn1<-c()
    for(i in unique(sgr))
      xnn1 <- cbind(xnn1, array(sample(x1[,gr==i]),c(nr,sum(gr==i))))
    xnn1<-xnn1*xmses
    ##xnn2<-rbind(xnn2,xnn1)
    xf1<-rbind(xf1,rF(xnn1,sgr))
    Xmases<-c(xmse1,sqrt(c(rmse(xnn1,sgr))))
  }
  
  xmses <- sort(xmse1)[(1:nr) * 10 - 5]
  sxmse <- sort(xmse)
  xspp <- smdecreasing(smooth.spline(xmses, sxmse), sxmse, F)
  xmses <- sample(xspp, replace= F)
  
  ##xnn2<-c()
  xf1<-c()
  xmse1<-c()
  #browser()
  for (j in 1:20) {
    
    xnn1<-c()
    for(i in unique(sgr)){
      xnn1 <- cbind(xnn1, array(sample(x1[,gr==i]),c(nr,sum(gr==i))))
    }
    xnn1<-xnn1*xmses
    ##xnn2<-rbind(xnn2,xnn1)
    xf1<-rbind(xf1,rF(xnn1,sgr))
    xmse1<-c(xmse1,sqrt(c(rmse(xnn1,sgr))))
  }
  i <- sort.list(xmse1)
  n <- length(xmse1)
  mm <- 1000
  n1 <- n%/%mm
  n <- mm * n1
  xmse2 <- array(xmse1[i][1:n], c(mm, n1))
  xf2 <- abs(array(xf1[i,1][1:n], c(mm, n1)))
  if (flag) 
    xq2 <- csort(abs(xf2))[round((0.5 + qi/2) * mm), ] else xq2 <- apply(
      abs(xf2), 2, quantile, 0.5 + qi/2)
  xp2 <- cmean(xmse2)
  if (length(qi) == 1) 
    xfp <- smdecreasing(smooth.spline(log(xp2), log(xq2), 
                                        df = dg), log(xmse)) else {
                                          xfp <- smdecreasing(smooth.spline(log(xp2), log(xq2[1,]), df = dg), log(xmse))
                                          for (i in 2:length(qi)) xfp <- cbind(xfp, smdecreasing(smooth.spline(log(xp2), log(xq2[i, ]), df = dg), log(xmse)))
                                        }
  
  xfp <- exp(xfp)
  i2 <- abs(xf) > xfp[, length(qi)]
  #browser()
  #plot(xmse^0.5, (xf)^0.5, pch = ".")
  #points(xmse[i2]^0.5, xf[i2]^0.5, col = 2, pch = 18)
  #matlines(xmse[i2 <- sort.list(xmse)]^.5, xfp[i2, ]^0.5, lty = 1)
  #browser()
  dimnames(xfp)[[2]] <- paste("Fcut", qi, sep = "")
  z <- cbind(T = c(xf), xfp, Sp = xmse)
  if (is.null(dimnames(x)[[1]])) 
    dimnames(z)[[1]] <- 1:nrow(x)
  else dimnames(z)[[1]] <- dimnames(x)[[1]]
  z[1:topgn,]
}

# =============================================
cF = function (x, gr, qi = c(0.2,0.4,0.6,0.8,0.9,0.95,0.99,0.999), bsz = 200, plotenv = F, tol = 10^(-10)) {
  ### Raws of x are Genes, Columns of x are samples  #####
  require(quantreg);require(DNAMR)
  x <- toarray(x)
  tk <- c(table(gr))
  ngr=length(tk)
  sgr <- sort(gr)
  xsp <- rsd(x)
  isp = !is.na(xsp)
  xx = x[isp, ]
  xt <- rF(xx, gr)[,1]  # xt
  xsp <- sqrt(c(rmse(xx,gr)))####  xsp
  n <- nrow(xx)
  mx <- ncol(xx)
  u = xx[xt < 1.5, ]
  u = (u - rmean(u))/rsd(u)
  k = 10
  xspp <- sxps <- sort(xsp)
  for (l in 1:5) {
    x1 <- array(sample(u,k*2*n*mx,replace=T),c(k*2*n,mx))*rep(xspp,2)
    xsp1 <- sqrt(c(rmse(x1,gr)))####  xsp
    xsps <- sort(xsp1)[(1:n)*2*k - k]
    xspp = sort(xspp + 1/l * (sxps - xsps))  
  }
  k = 30; kk = 40000
  xsps <- sample(xspp, replace= F)
  pnnn=n*mx*k
  xnn1 <- array(sample(u,pnnn,replace=T), c(n*k,mx)) * xsps
  xt1 <- rF(xnn1,gr)[,1]
  xsp1 <- sqrt(c(rmse(xnn1,gr)))####  xsp
  kk = min(jj<- length(xsp1),kk)
  if(jj==kk) i = 1:jj else  i = round(seq(from=jj/kk,to=jj+1-jj/kk,length=kk))
  l1 = log(xsp1[i])
  l2 = log(abs(xt1[i]))
  ii = is.finite(l1+l2)
  ccc = rq(l2~l1+I(l1^2)+I(l1^3),qi,sub=ii)$coef
  m1 = log(xsp); m2 = log(abs(xt))
  out = cbind(abs(xt),exp(cbind(1,m1,m1^2,m1^3)%*%ccc),xsp)
  dimnames(out) = list(rownames(xx),c("T", paste("Curve",qi, sep = ""),"Sp"))
  if (all(isp)) return(ctpval(out))
  res = array(0, c(nrow(x), ncol(out)), dimnames = list(rownames(x), 
                                                        colnames(out)))
  res[isp, ] = out
  ctpval(res)
}

wfda <- function(x,k=0.01,mlog=T){
  n = length(x)
  u = x[sort.list(x)]
  u = c((u[-1] + u[-n])/2,u[n])
  u[sort.list(x)]= u/(1:n)*n;
  u[ u > 1 ]= 1
  u[ u < 0.00001] = 0.00001
  u = if(mlog) -log(u) else 1/u
  u[u<k]=k
  u = fmonotone(u,-x)
  u
}

fmonotone <-  function(i,ii,n=length(i)){i=i[sort.list(ii)] ;
  for( j in 2:n) i[j] = max(i[j],i[j-1]);
  i[rank(ii)]}

#
#
########################### P-value Function: ctpval   ########################
#  This function uses the ouput of ct to generate p-values. In oder to
#  obtain reasonably accurate p-vals use the qi option with 
#  multiple values: ctpval(ct(x,y,qi=c(0.5,0.9,0.95,0.99,0.999))) 
#
ctpval = function(x.ct,nch=6, tol = 10^(-10)) {
out = x.ct[,1,drop=F]
isp = !is.na(c(out)) & abs(c(out)) > tol
xx = x.ct[isp,]
out[!isp,]=1
p <- ncol(xx) 
pr = 2:(p-1)
x <- log(xx[,pr])
n = nrow(xx)
p2 <- p-2
u <- as.numeric( substring(dimnames(x.ct)[[2]][pr],nch))
y = log(-log(1-u))
xm = c(x%*%rep(1,p2)/p2)
x2 = (x-xm)^2 %*%rep(1,p2)
xy = (x-xm)%*%(y-mean(y))
b = xy/x2
m = mean(y)-b*xm
out[isp,] = exp(-exp(m+b*log(abs(xx[,1]))))
out
}
#
#
########################## ctcmu Function: ctcmu   #######################
#  This function uses the ouput of ct to generate p-values. In oder to
#  obtain reasonably accurate p-vals use the qi option with 
#  multiple values: ctpval(ct(x,y,qi=c(0.5,0.9,0.95,0.99,0.999))) 
#
ctcmu =  function (x,y, qi = c(0.95,0.99),bsz= 200) {
  mu = rmean(cbind(x,y))
  mui = sort.list(mu)
  n=nrow(x)
  bszl=min(200,n%/%5)
  bn = 5*bszl
  k = length(qi)+2
  k1 = 1:k
  bk = 1:bszl
  nq = (n -bn)%/%bszl
  jj=matrix(NA,n,5*k,dimnames=list(rownames(x),NULL)) 
  for(i in 0:nq) {
  j = mui[bszl*i + 1:bn]
  if(i ==nq) j = mui[(bszl*i + 1):n]
  temp =ct(x[j,],y[j,],qi,bsz)
  for(l in 0:4) jj[j[l*bszl+bk],(4-l)*k+k1] = temp[l*bszl+bk,]
  }
i= 1+ (0:4)*k
z = apply(jj[,i],1,max,na.rm=T)
for(j in 1:(k-2)) z = cbind(z,
apply(jj[,i+j],1,function(x){ x=x[!is.na(x)]; n=length(x); mean(x[(n+ 1:2)/2]) }))
   colnames(z) <- c("T", paste("Curve",qi,sep=""))
cbind(z,  Sp=apply(jj[,i+k-1],1,max,na.rm=T) )
}
#
#
########################### Envelop Function: renv ########################
#
#
renv <- function(x,y,x0=x,y0=y,type= c("dec","inc","none")[3], m=20,lqi=0.05,hqi=0.95,sym=F,plot=T,flag=F,dg=8,logtran=F) {
#  x, y are the coordinates of the points used to generate the
#       envelope.
#  x0, y0 are the points that are graphed with the envelop.
#        By default x0=x y0=y
#  type:  constraints to the envelop function, increasing decreasing or none. 
#  m = block size for constructing the quantile envelop
    qi <- c(if(!is.null(lqi)) sort(lqi),if(!is.null(hqi)) sort(hqi))
    if (logtran){x = log(x); x0 = log(x0); y =log(y); y0= log(y0)}
    if(sym) {
       qi = unique(sort(pmax(qi,1-qi))); lqi <- NULL; y1= abs(y)} else {y1=y}
    n <- length(x)
    n1 <- n%/%m
    n0 <- m * n1
    i =  sort(sample(n,n0))    
    i <- sort.list(x)[i]
    xsp2 <- array(x[i], c(m, n1))
    xt2 <- array(y1[i], c(m, n1))
   if (sym) xt2 <- abs(xt2) 
   zz <-csort(xt2)
   if (flag) 
        xq2 <- zz[round(qi * m), ]
   else xq2 <- apply(xt2, 2, quantile,qi)
    xp2 <- cmean(xsp2)
    if(!sym) { 
        xmed <- zz[round(m/2),]
        xq2  = t(t(xq2)-xmed)
        ymed = predict(smooth.spline(xp2,xmed,df=dg),x)$y
        y1   = y1-ymed
        } else { xmed<- rep(0,ncol(zz));ymed= rep(0,n) } 
tt = function(xq,qq) {
       xxtp <- smooth.spline(xp2,xq,df=dg)
       w = predict(xxtp,x)$y
       kc = quantile(y1/w,if(qq>0.5) qq else 1-qq)       
       w=predict(xxtp,x)$y*kc+ymed
       as.matrix(predict(smooth.spline(x,w),x0)$y)
}
vv = function(xq,qq) {
       xxtp <- smooth.spline(xp2,xq+xmed,df=dg)
       w = smdecreasing(xxtp,x,decreasing=down)
       kc = quantile((y1)/(w-ymed),if(qq>0.5) qq else 1-qq)       
       zz=(w-ymed)*kc+ymed
       w= zz+ quantile(-zz+y1+ymed,qq)
        as.matrix(predict(smooth.spline(x,w),x0)$y) 
}
if(type == "none") {
 if(length(qi) == 1) {xtp <- tt(xq2,qi)} else {
 xtp <- tt(c(xq2[1,]),qi[1]); for(i in 2:length(qi))xtp <- cbind(xtp,tt(c(xq2[i,]),qi[i]))
    }    } else { if(type=="inc") down=F
                  else if(type=="dec") down=T
    if(length(qi) == 1) {xtp <- vv(xq2,qi)} else {
       xtp <- vv(c(xq2[1,]),qi[1]); for(i in 2:length(qi))xtp <- cbind(xtp,vv(c(xq2[i,]),qi[i]))    }
   }
   if (logtran){xtp=exp(xtp); x0 = exp(x0); y0= exp(y0)}
if(plot) { 
   plot(x0,y0,pch=".",xlab="Sd",ylab="|T|")
   par(cex=0.5)
   npc=16; ccc=5
   if (!is.null(hqi)) { i2 <- y0 > xtp[,length(qi)] 
          points(x0[i2],y0[i2],col=ccc,pch=npc) }
   if (!is.null(lqi)) { i2 <- y0 < xtp[,1] 
          points(x0[i2],y0[i2],col=ccc,pch=npc) }
   if (sym) { i2 <- y0 < -xtp[,length(qi)] 
          points(x0[i2],y0[i2],col=ccc,pch=npc) }
  par(cex=1)
   matlines(x0[i2 <- sort.list(x0)],xtp[i2,],col= 3,lty = 1)
 }
  if(sym) matlines(x0[i2], -xtp[i2,], col= 3,lty = 1)
   dimnames(xtp) <-list(dimnames(xtp)[[1]], paste("Curve",qi,sep=""))
   cbind(T = c(y0),xtp,Sp=x0)
}
#
#
###############################  Other functions ##############################
#
#
#
smdecreasing = function(z,w,decreasing=T) {
# z output of smooth.spline with x component sorted.
# The y component of z must be non increasing, if not the 
#    function willmake it non-increasing
# Extrapolations are linear
x <- z$x
n <- length(x)
if( n < 20) return(z$y)
if(decreasing) y <- z$y else y <- (-z$y)
rx <- range(x)
rw <- range(w)
while( any (diff(y) >0) ) y <- pmax(y,y[c(2:n,n)])
i1 <- (w < rx[1])
i2 <- (w > rx[2])
i <- !(i1|i2)
w1 <- w
if(any(i)) w1[i] <- approx( x,y,w[i])$y
if(any(i1)) { 
        m1 <- lsfit(x[1:20],y[1:20])$coef[2]
        w1[i1] <- approx( c(rw[1],x[1]),c(y[1]-m1*(x[1]-rw[1]),y[1]),w[i1])$y
}
if(any(i2)) { 
        m2 <- lsfit(x[n-0:19],y[n-0:19])$coef[2]
        w1[i2] <- approx( c(x[n],rw[2]),c(y[n],y[n]-m2*(x[n]-rw[2])),w[i2])$y
}
if (decreasing) w1 else -w1
}

#
#
#
###########################################################
#          CODE FOR T-TEST
# rsdrsp rssp rttest mad cv  
###########################################################
#rsd = function(x) sqrt(rvar (x))
#csd = function(x) sqrt(cvar (x))

rsp = function(x1, x2,n1=ncol(x1)-1,n2=ncol(x2)-1) sqrt((n1*rvar(x1)+n2*rvar(x2))/(n1+n2))

csp = function(x1, x2) rsp(t(x1),t(x2))

# rmean = function(x,n=ncol(x)) c(x%*%rep(1,n))/n
# rvar  = function(x,n=ncol(x)) c((x-rmean(x))^2 %*%rep(1,n))/(n-1)
# toarray = function(x) array(unlist(x) , dim(x), dimnames(x))
 rssp = function(x1,x2)rsp(x1,x2)*sqrt(1/ncol(x1) +1/ncol(x2))
# rttest = function(x1,x2,fu=0) (rmean(x1)-rmean(x2))/
#        (t(array(fu,c(nrow(x1),length(fu))))+rssp(x1,x2))

rttest = function(x,y,fudge.factor=0,  
alternative = c("two.sided", "less", "greater")[1],var.equal=FALSE,
    num.thresh=10^(-6),denom.thresh=10^(-6)) { 
#Note that y coul dbe either another array like x or a grouping vector.
  if((nc<-ncol(x))==length(y) & length(zz<-unique(z<-y))==2){
    y=x[,z!=zz[1]]
    x=x[,z==zz[1]]
  }
  num = (rmean(x)-rmean(y)) 
  nx =ncol(x);ny=ncol(y)
  vx = rvar(x); vy=rvar(y)
  rssxy =if(var.equal) sqrt(((nx-1)*vx+(ny-1)*vy)/(nx+ny-2)*(1/nx+1/ny))else 
                      sqrt(vx/nx+vy/ny)
    den = t(array(fudge.factor,c(nrow(x),length(fudge.factor))))+rssxy 
    i = abs(num ) < num.thresh & den < denom.thresh
    num[i]=0; den[i]=1 
    T=c(num/den)
  dd=if(var.equal) nc-2 else (vx/nx +vy/ny)^2  /((vx/nx)^2/(nx-1) +(vy/ny)^2/(ny-1))
  
  pv=pt(T,df=dd)  
  if(alternative=="greater") pv = 1-pv
  if(alternative=="two.sided") pv = 2*pmin(pv,1-pv)
   m = cbind(T=T,DF=dd,PV=pv)
  rownames(m) = rownames(x)
  m
 } 

#rmad <- function(x,na.rm=T) rmedian(abs(x-rmedian(x)))

# rcv  <- function(x) {
# num = rsd(x)
# den = rmean(x)
# den[num ==0] = 1
# num/den
# }
#####################################################
#       CODE FOR SAM
#   fudge.factor sam
#####################################################
fudge.factor <- function(x1,x2,tol = (10^(-10)) )  {
# x1 and x2 are two array with the same number of rows. No missing values are allowed.
  xsp <- rsd(cbind(x1,x2))
  isp =  !is.na(xsp)  &  xsp>tol 
  if(!all(isp)) { x1 = x1[isp,]; x2 = x2[isp,]}
  xt <- rttest(x1,x2)[,1]
  xsp <- rssp(x1,x2)
  qq <- quantile(xsp,(0:100)/100)
  aa <- quantile(xsp,(0:20)/20)
  gr <-as.numeric(cut(xsp, breaks=qq, left.include=T,include.lowest=F) )
  gr[is.na(gr)] <- 100
  ugr <- unique(gr)
  to <- matrix(0,length(aa),length(ugr))
  mx <- rmean(x1)-rmean(x2)
  sp <- rssp(x1,x2)
  for(i in 1:length(ugr)) {
     k <- gr==ugr[i]
     to[,i] <- apply(mx[k]/outer(sp[k],aa,"+"),2,mad)  
  }
  too <- apply(to,1,cv )
  aa[sort.list(too)[1]]
}  
 
sam <- function( x, y, delta, ns=100, delgr=2) 
{ 
  n1 <- ncol(x); n2 <- ncol(y); n <- n1+n2 
  
  ## Convert data into matrix format
  x <- toarray(x)
  y <- toarray(y)
  ## Delete missing values
  i <- !is.na( x%*%rep(1,n1) + y%*%rep(1,n2) )
  x <- x[i,]; y <- y[i,]

  ng <- sum(i)
  ## Calculate the SAM constant
  con <- fudge.factor(x,y)
  ## Perform permutation argument
  to <- samperm(x,y,con,ns)
  db <- rmean(to) 
  d <- rttest( x, y, con ) 
  dimnames(d) <- list(NULL, dimnames(x)[[1]])
  ii <- sort.list(d);     
  d <- d[,ii] # let d keep gene names 
  clow <- cup <- sn <- NULL 
  if(missing(delta)) {
    qd <- round(quantile(abs(db-d),c(0.2,0.999)),2)
    bb <- (qd[2] - qd[1])/15
    b0 <- 10^-floor(log(bb,10))
    bb <- trunc(bb*b0)/b0
    delta <- seq( from=qd[1],to=qd[2],by=bb)
  }
  nsn  <- array( 0, c(length(delta),2) ) 
  ## Draw the basic SAM graph 
  par(pty="s") 
  rr <- range( c(d,db) ) 
  plot( rr, rr, type="n", xlab="Ave d(i)", ylab="d(i)" ) 
  significant <- abs(db-d) > delgr 
  points( d[!significant], db[!significant], col=4 )
  points( d[significant], db[significant], col=2 ) 
  abline( 0, 1 ) 
  abline( delgr, 1, col=3 ) # the upper threshold 
  abline(-delgr, 1, col=3 ) # the lower threshold 
  abline( h=0, v=0 ) # the coordinate axis through the origin 
  ## Calculate the FP, Called, FDR 
  for ( i in 1:length(delta) ) {
    clow[i] <- max( d[sig.induced <- d < (db-delta[i])] )
    cup[i]  <- min( d[sig.repressed <- d > (db+delta[i])] )
    sn[i]   <- sum(sig.induced) + sum(sig.repressed)
    qq <- c( rep(1,nrow(to))%*% ( (to > cup[i]) | (to < clow[i])) )
    nsn[i,] <- quantile( qq, c(0.5,0.9) )
  } 
  prun <- quantile( to, c(0.25, 0.75) )
  p    <- min( sum(d <prun[2] & d > prun[1])/ng*2, 1 )
  nsn  <- nsn*p
  ## Output. 
  statistics = cbind( ii, abs(db-d) ) 
  dimnames(statistics)[[2]] <- c("Row.number", "Delta")
  list( round( cbind( Delta = delta, 
                      "FalsePositive50%" = nsn[,1], 
                      "FalsePositive90%" = nsn[,2], 
                      Called = sn, 
                      "FDR50%" = nsn[,1]/sn, 
                      "FDR90%" = nsn[,2]/sn ), 
               4 ), 
        statistics,
        attr(d, "names")[significant] ) 
}

permtwo <- function( n ,k) { 
   x <- c(0,1) 
   y <- NULL 
   for(i in 2:n) { 
      x <- rbind(cbind(x,0),cbind(x,1)) 
      j <- c(x%*%rep(1,i)) 
      jj <- j==k 
      if((ni <-sum(jj)) > 0) { 
       xx <- matrix(0,ni,n) 
       xx[,1:i] <-x[jj,] 
       y <- rbind(y,xx) 
      } 
      x <- x[j <k & (j+n-i)>=k,] 
   } 
  
 t(apply(y,1,function(x)c((1:length(x))[x==1],(1:length(x))[x==0]))) 
 } 
comb <- function(g) 
   round(exp(sum(log(1:sum(g)))-sum(sapply(g,function(x)sum(log(1:x))))))


samperm <- function(x,y,con, ns=100) { 
   n <- (n1 <- ncol(x)) + (n2 <- ncol(y))

   if( (kk <- comb(c(n1,n2))) < ns) { 
        ns <- kk; 
        ii <- permtwo(n,n1)  
      } 
   else if(kk < 20000) 
        ii <- permtwo(n,n1)[sample(kk,ns),] 
   else  ii <- t(sapply(rep(n,ns),sample))  
  ## Perform permutation argument
  xx <- cbind( x, y )

  to <- permmean(xx,ii,n1,con)       
  csort(to) 
}

permmean <- function(xx,ii,k=4,con=0.01) {
  dx <- dim(xx)
  ns = nrow(ii)
  n = ns %/%20
  nr = ns - n*20
  zt <- NULL
  if(n>0)
    for(i in 0:(n-1)) { 
      jj <- c(ii[i*20+1:20,] ) 
      z <- xx[, jj] 
      dim(z) <- dx*c(20,1) 
      zt <- c(zt,rttest(z[,1:k],z[,-(1:k)],con))
    }
  if(nr>0)  { 
      jj <- c(ii[ns-nr + 1:nr ,] ) 
      z <- xx[, jj] 
      dim(z) <- dx*c(nr,1) 
      zt <- c(zt,rttest(z[,1:k],z[,-(1:k)],con))
  }
dim(zt) <- c( dx[1],ns)
zt
}

### This function is not in use
plms <- function(exx,...) {
  xm <- rmean(exx)
  sx <- rsd(exx)
  plot(log(xm),log(sx),...)
  lines(smooth.spline(log(xm),log(sx)),lwd=3,col=2)
  abline(v=median(log(xm)),col=4)
  invisible() 
}

##
##  CLUSTER ANALYSIS
##
clusterTEMP <- function(X, nclust, logtran=T ,kval=0, qnorm=T ,opt="ward.D") {
X <- toarray(X)
if(is.na(kval) | !(kval > -Inf)) kval <- 0
if (logtran) X<- log(X-kval)
if(qnorm) X <- cnormalize(X)
#X <- X[corsub(X,maxng),]
#opp = list("single","complete", "average","ward.D", "mcquitty", "median","centroid")
#names(opp)=c("single","complete", "average","ward", "mcquitty", "median","centroid")
#opt=opp[[opt]][1]
if (is.missing (nclust))
nclust <- second_der(X, method= opt,jrange = 3:25,hc.method = opt)[[1]][1]
hh = hclust(dist(X))
plot(hh,hang=-0.1)
as.matrix(cutree(hh,nclust))
}

corsub <- function(X,maxn,nb=20,maxc=0.97,mx=10) {
 maxX <- apply(X,1,max) 
if(missing(maxn))  kk <- maxX > (max(X)/mx) else
                  kk <- sort.list(-maxX)< (nrow(X) +maxn )/2
        X <- X[kk,] 
        n <- nrow(X)
        nn <- n%/%nb
        jj <- rep(0,n)
        for(i in 1:nn) {
                ii  <- (i-1)*nb + 1:nb  
                tt  <-cor(t(X[ii,]),t(X[-ii,]) )
                tt1 <- cor(t(X[ii,]))
                diag(tt1) <- 0
                tt  <- abs(cbind(tt,tt1))
                jj[ii] <- apply(tt,1,max)
        }
        if (n < nn*nb) { 
                ii <- (nn*nb+1):n
                tt1 <- cor(t(X[ii,])); diag(tt1) <- 0 
                jj[ii]<- apply(abs(cbind(cor(t(X[ii,]),t(X[-ii,])),tt1)),1,max)
        }
if(missing(maxn))  kk[kk] <- (jj > maxc) else
                  kk[kk] <- sort.list(-jj)<= maxn
kk
}

rsq <- function(x,gr) {
   xm <-rmean(x)
sum( t((cmat(x,gr) - xm)^2)* c(table(gr)))/sum((x-xm)^2)
}
cmt <- function(x,gr) {
    x <- x[,sort.list(gr)]
  tk <- c(table(gr))
  p <- length(tk)
  ttk <- cbind(rep(tk,p),0)
  ttk[1+(p+1)*(0:(p-1)),2] <- 1
  z <- array(rep(ttk[,2],ttk[,1]),c(length(gr),p))
  t(t(x%*%z)/tk)
}

cmat <- function(x,gr,na.rm=F) {
  x = as.matrix(x)
  nai <- unique(gr)
  ngr = length(nai)
  xs= array(NA,dim=c(nrow(x),ngr),dimnames=list(NULL,nai))
  for(i in 1:ngr) 
    xs[,i] <- rmean(x[,gr == nai[i],drop=F],na.rm=na.rm)
  xs 
}

############### PCA ################################

is.2D=function(x) 
is.matrix(x) & length(dim(x))==2 & all(dim(x)>0)

enriched.PCA= function(x,gr) {
  ww=wcomp(x, gr)
  weighted.PCA(t(x),wcol=ww)
}

weighted.PCA=function(x,wrow=rep(1,nrow(x)),wcol=rep(1,ncol(x)),corr=T,method=c("svd","eigen") ){
  mx = apply(x,2,mean); p = ncol(x); n= nrow(x)
  wcol=wcol/sum(wcol)*p
  sx= if(corr) apply(x,2,sd) else 1
  y = (t(x)-mx)/sx*wcol
  y = t(y)*wrow
  if(method[1]=="svd") { 
    res=prcomp(y) 
    res$sdev=res$sdev*sqrt((n-1)/(sum(wrow)-1)) 
  } else if(method[1]=="svd2") {  
    if(p>n) {sv = svd(t(y)/sqrt(sum(wrow)-1))
            rot = sv$u ; xx = y%*%rot
    } else {sv = svd(y/sqrt(sum(wrow)-1))
    rot = sv$v ; xx = y%*%rot}
    res=list(sdev= sv$d,rotation= rot,
             x = xx,center=mx,scale=if(corr)sx else 1)
    }
    else  if(method[1]=="eigen") {
  y=t(y)
  sig = y%*%t(y)/(sum(w)-1)
  ei = eigen(sig)
  if(n<p) {ei$values = ei$values[1:n]; ei$vectors = ei$vectors[,1:n]}
  ei$values[abs(ei$values)< 10^(-10)]=abs(ei$values[abs(ei$values)< 10^(-10)])
    res=list(sdev= sqrt(ei$values),rotation= ei$vectors,
       x = t(t(ei$vectors)%*%y),center=mx,scale=if(corr)sx else 1)
} 
res$wrow = wrow
res$wcol= wcol
  res
}

enriched.glmnet= function(x,y,alpha=1,
  family = c("gaussian", "binomial", "poisson", "multinomial")[1],...) {
  
  famlist = c("gaussian", "binomial", "poisson", "multinomial")
  meth= c("cor","ct","cor","cF")
  
  meth0=if(family==famlist[1]) meth[1] else if(family== famlist[2]) meth[2]
  else if(family==famlist[3]) meth[3] else if(family== famlist[4]) meth[4]
  else meth[1]
  
  y1= if (family=="poisson") sqrt(y) else y
  ww=wcomp(t(x), y1,method=meth0)
  weighted.glmnet(x,y,wcol=ww,family=family,...)
}

weighted.glmnet= function(x,y, wcol=1,family="gaussian",alpha=1,lambda,...){
  x=toarray(x)
  sx= csd(x)
  x = t(t(x)*wcol/sx)
  if(missing(lambda)) {cvsel=cv.glmnet(x,y,family=family,standardize=F,...);
  cvsel=c(cvsel$lambda.min,cvsel$lambda.1se)} else cvsel=lambda
  glmnet(x,y,lambda=cvsel,family=family,standardize=F,...)
}
################################# F test ##########
rF <- function(x,g) { 
  if(!is.matrix(x))x= toarray(x)
   tk <- c(table(g));   k <- length(tk) 
   i= sort.list(g); x =x[,i]; g=g[i]
   ttk <- cbind(rep(tk,k),0) 
   ttk[1+(k+1)*(0:(k-1)),2] <- 1 
   cm <- t(t(x%*%array(rep(ttk[,2],ttk[,1]),c(length(g),k)))/tk) 
   xm <- rmean(x)  
   tss <- (x - xm)^2 %*% rep(1,n <- ncol(x)) 
   bss <- (cm - xm)^2 %*%c(table(g))  
   F <-  bss/(k-1) /(tss-bss)*(n-k) 
   mfc <-  apply(cm,1,range); mfc <-mfc[2,]-mfc[1,] 
   data.frame(F=F, pval= 1-pf(F,k-1,n-k),LogFoldChange=mfc ) 
} 


############## CLASSIFICATION #######################
classification <-  function(X,Y, logtran=T ,kval=0, qnorm=T,retgenes=T,ngenes=100,  
 retnpc=T,npc=2, opt="lda",trcolname=T, trrand=F, trrandpct=50, trcv=F, cvk=1) {
 library(MASS)
 library(class)
 library(nnet)
  if (any(i<-is.na(Y))) { Y=Y[!i]; X <- X[,!i]}  
  X <- toarray(X)
  p <- ncol(X)
  if(is.na(kval) | !(kval > -Inf)) kval <- 0
  if (logtran) X <- log(X-kval)
  if(qnorm) X <- cnormalize(X)
  if (retgenes<1) ngenes <- 100
  if (retnpc<1) npc <- 5
  WW <- summ(X,Y,npc,ngenes)
if(trcolname) {
          itrain <- grep("TRAIN", dimnames(X)[[2]])
          itest <- grep("TEST", dimnames(X)[[2]])
  } else if (trrand ) {
     pk = table(Y)
     cumpk= c(0,cumsum(pk))
     mpk =  sort.list(-pk)[1]
     m  <-p*trrandpct/100
     pm  <-round(pk*trrandpct/100)
     pm[mpk] = m - sum(pm[-mpk])
     itrain <- NULL
     for(i in 1: length(pk)) itrain <- c(itrain,cumpk[i]+ sample(pk[i],pm[i],replace=F))
	itrain <- sort(itrain)
     cat(itrain)
     itest  <- (1:p)[-itrain]
     cat(itest)
  } else if(trcv) {
     itrain <- 1:p
     itest <- numeric(0)
  }
  W <-data.frame(WW[itrain,],Y=Y[itrain])   
  Wc <-data.frame(WW[itest,],Y=Y[itest])   
  if(opt=="lda") {
        z <- lda(Y ~ ., data=W,CV=T);zclass=as.character(z$class)
        u <- table(W$Y,zclass)
        dimnames(u)[[1]] <- paste("Observed", dimnames(u)[[1]])
        dimnames(u)[[2]] <- paste("Predicted",dimnames(u)[[2]])
        w <- data.frame(zclass,round(z$posterior,3))
        dimnames(w)[[2]] <- c("Group",paste("Prob.Class",sort(unique(Y[itrain])),sep="_"))
     if(length(itest) > 0) {
        zt <- predict(lda(Y ~ ., data=W),Wc)
        ut <- table(Y[itest],zt$class)
       dimnames(ut)[[1]] <- paste("Observed", dimnames(ut)[[1]])
        dimnames(ut)[[2]] <- paste("Predicted",dimnames(ut)[[2]])
        wt <- data.frame(as.character(zt$class),round(zt$posterior,3))
        dimnames(wt)[[2]] <- c("Group",paste("Prob.Class",sort(unique(Y[itrain])),sep="_"))
        return(list('Linear discr anal. Performance Assesment Table For Training Set'=u,TrainingSet=w,
               'Linear discr anal. Performance Assesment Table For Testing Set'=ut,TestSet=wt))
     } else return(list('Linear discr anal. Performance Assesment Table For Training Set'=u,TrainingSet=w))
  }
  if(opt=="qda") {
        z <- qda(factor(Y) ~ ., data=W,CV=T)
        u <- table(W$Y,z$class)
        dimnames(u)[[1]] <- paste("Observed", dimnames(u)[[1]])
        dimnames(u)[[2]] <- paste("Predicted",dimnames(u)[[2]])
        w <- data.frame(z$class,round(z$posterior,3))
        dimnames(w)[[2]] <- c("Group",paste("Prob.Class",sort(unique(Y[itrain])),sep="_"))
     if(length(itest) > 0) {
        zt <- predict(qda(Y ~ ., data=W),data.frame(WW[itest,]))
        ut <- table(Y[itest],zt$class)
        dimnames(ut)[[1]] <- paste("Observed", dimnames(ut)[[1]])
        dimnames(ut)[[2]] <- paste("Predicted",dimnames(ut)[[2]])
        wt <- data.frame(zt$class,round(zt$posterior,3))
        dimnames(wt)[[2]] <- c("Group",paste("Prob.Class",sort(unique(Y[itrain])),sep="_"))
        return('Quadratic discr anal. Performance Assesment Table For Training Set'=u,TrainingSet=w,
               'Quadratic discr anal. Performance Assesment Table For Testing Set'=ut,TestSet=wt)
     } else return('Quadratic discr anal. Performance Assesment Table For Training Set'=u,TrainingSet=w)
  }
  if(opt=="knn") {
        z <- knn.cv(WW[itrain,],Y[itrain],k=5,prob=T)
        u <- table(Y[itrain],z )
        dimnames(u)[[1]] <- paste("Observed", dimnames(u)[[1]])
        dimnames(u)[[2]] <- paste("Predicted",dimnames(u)[[2]])
        w <- data.frame(z,attr(z,"prob"))
        dimnames(w)[[2]] <- c("Classification Group","Prob.Class")
     if(length(itest) > 0) {
        zt <- knn(WW[itrain,],WW[itest,],Y[itrain],k=5,prob=T)
        ut <- table(Y[itest],zt )
        dimnames(ut)[[1]] <- paste("Observed", dimnames(ut)[[1]])
        dimnames(ut)[[2]] <- paste("Predicted",dimnames(ut)[[2]])
        wt <- data.frame(zt,attr(zt,"prob"))
        dimnames(wt)[[2]] <- c("Classification Group","Prob.Class")
        return('K-nearest neighbours anal(K=5). Performance Assesment Table Training Set'=u,
        'Classification Training'=w,'Performance Assesment Table Testing Set'=ut,'Classification Testing'=wt)
     } else return('K-nearest neighbours anal(K=5). Performance Assesment Table For Training Set'=u,TrainingSet=w)
    }
  if(opt=="ann") {
        w <- ranncv(W) 
        u <- table(W$Y,w[,1])
        dimnames(u)[[1]] <- paste("Observed", dimnames(u)[[1]])
        dimnames(u)[[2]] <- paste("Predicted",dimnames(u)[[2]])
        dimnames(w)[[2]] <- c("Class.Group",paste("Prob.Class",sort(unique(W$Y)[1:(ncol(w)-1)]),sep="_"))
        if(length(itest) > 0) {
          z <- nnet(factor(Y)~.,data=W,maxit=300,skip=T,size=10)
          wwt <- round(predict(z,WW[itest,]),4)
          wt <- predict(z,WW[itest,],type="class")
          ut <- table(Y[itest],wt)
          dimnames(ut)[[1]] <- paste("Observed", dimnames(ut)[[1]])
          dimnames(ut)[[2]] <- paste("Predicted",dimnames(ut)[[2]])
          wt <- data.frame(wt,wwt)
          dimnames(wt)[[2]] <- c("Class. Group",paste("Prob.Class",sort(unique(W$Y)),sep="_"))
          return(
          'Neural Net. Performance Assesment Table for Training Set'=u,
          'Classification for Training Set'=w,
          'Performance Assesment Table for Testing Set'=ut,
          'Classification for Testing Set'=wt)
        } else {
        return('Neural Net. Performance Assesment Table for Training Set'=u,
               'Classification for Training Set'=w) }
  }
  if(opt=="pam") {
	u <- rpam(X[,itrain],Y[itrain])
        v <- table(Y[itrain],u[[1]])
        dimnames(v)[[1]] <- paste("Observed", dimnames(v)[[1]])
        dimnames(v)[[2]] <- paste("Predicted",dimnames(v)[[2]])
      if(length(itest) > 0) {
		ut =rpam.predict(X[,itest],u)
		wt = table(Y[itest],ut)	
        dimnames(wt)[[1]] <- paste("Observed", dimnames(wt)[[1]])
        dimnames(wt)[[2]] <- paste("Predicted",dimnames(wt)[[2]])
         list(
          'PAM. Performance Assesment Table for Training Set'=v,
          'Classification for Training Set'=as.matrix(u[[1]]),
          'Performance Assesment Table for Testing Set'=wt,
          'Classification for Testing Set'=as.matrix(ut))
         } else
        list('PAM. Performance Assesment Table for Training Set'=v,
               'Classification for Training Set'=as.matrix(u[[1]]))
  }
  if(opt=="svm") {
        library(e1071)
	u <- svm(factor(Y) ~ ., data=W); zclass = as.charcter(u$fitted)
        v <- table(W$Y,zclass)
        dimnames(v)[[1]] <- paste("Observed", dimnames(v)[[1]])
        dimnames(v)[[2]] <- paste("Predicted",dimnames(v)[[2]])
      if(length(itest) > 0) {
		ut =rpam.predict(X[,itest],u)
		wt = table(Y[itest],ut)	
        dimnames(wt)[[1]] <- paste("Observed", dimnames(wt)[[1]])
        dimnames(wt)[[2]] <- paste("Predicted",dimnames(wt)[[2]])
         list(
          'PAM. Performance Assesment Table for Training Set'=v,
          'Classification for Training Set'=as.matrix(u[[1]]),
          'Performance Assesment Table for Testing Set'=wt,
          'Classification for Testing Set'=as.matrix(ut))
         } else
        list('PAM. Performance Assesment Table for Training Set'=v,
               'Classification for Training Set'=as.matrix(u[[1]]))
  }
}



summ <- function(x,y,npc,ng) {
       z <- rF(x,y)
       if(missing(ng)) ng <- 1000
       i <- sort.list(z[,2])[1:ng]
       x <- x[i,]
       xpc <- rpca(x)
       k <- xpc$sdev^2
       k <- sum(k > mean(k))
       if(missing(npc)) npc <- k
       xpc$scores[,1:npc]
}

rpam <-  function(x,y) {
	n <- nrow(x)
	p <- ncol(x)
	u <- unique(y)
	k <- length(u)
	mk <- sqrt(1/c(table(y)) + 1/n)
	mx0 <- rmean(x)
	mxi <- array(NA,c(n,k))
	xx <- x
	for(i in 1:k) { 
    		mxi[,i] <- rmean(x[,y==u[i]])
    		xx[,y==u[i]] <- xx[,y==u[i]]-mxi[,i]
	}
	dimnames(mxi)= list( dimnames(x)[[1]],u)
	sxi0 <- c( (xx^2)%*% rep(1,ncol(xx)))/(p-k)
	s0 <- median(sxi0)
	ssxi0 <- t(mk * t(array(sxi0,c(n,k)) +s0) )
	d0 <- (mxi - mx0)/ssxi0; q <- 20
	delta <- seq(0,max(d0),length=q)
	res <- array( NA, c(p,q))
	for(j in 1:p) { 
        	mk <- sqrt(1/c(table(y[-j]))+ 1/(n-1))
        	mx <- rmean(x[,-j])
        	mxi[,y[j]] <- rmean(x[,-j][,y[-j]==y[j]])
        	xx[,y==y[j]] <- x[,y==y[j]]-mxi[,y[j]]
        	sxi <- c( (xx[,-j]^2)%*% rep(1,p-1))/(p-k-1)
        	s0 <- median(sxi)
        	ssxi <- t(mk * t(array(sxi,c(n,k)) +s0) )
        	d <- (mxi - mx)/ssxi
    	for(i in 1:q) { 
        	dp <- sign(d)* pmax( abs(d) - delta[i], 0)
        	mxip <- mx + ssxi*dp
        	res[j,i]<-u[sort.list(cmean((mxip-x[,j])^2))[1]] 
        }
        mxi[,y[j]] <- rmean(x[,y==y[j]])
        xx[,y==y[j]] <- x[,y==y[j]]-mxi[,y[j]]
	}
	wmax <- max(w <- cmean(res==y))
	j  <- max((1:length(w))[w==wmax])
	dp <- sign(d0)*pmax(abs(d0)-delta[j],0)
	mxip = mxip <- mx0 + ssxi0*dp
       res =NULL; for(i in 1:p) res[i]<-u[sort.list(cmean((mxip-x[,i])^2))[1]] 
	genes <- dimnames(x)[[1]][(i<-rmean(dp^2))>0]
	list(class=res,genes=genes[sort.list(-i[i>0])], 
             PctCorrect=mean(res==y),Delta=delta[j],GroupMeans=mxip,GeneWeights=dp)
}

rpam.predict <- function(x, obj) {
 res =NULL
 u = unique(obj[[1]])
 for(i in 1:ncol(x)) 
    res[i]<-u[sort.list(cmean((obj[[5]]-x[,i])^2))[1]]
res
} 

#csmin <- function (x) 
#{
#    n <- nrow(x)
#    p <- ncol(x)
#    rx <- range(x)
#    z <- (x - rx[1])/(rx[2] - rx[1]) * 0.99
#    k <- rep(1:p, rep(n, p))
#    z <- sort.list(z + k)
#    dim(z) <- dim(x)
#    z[1,] - n*(0:(p-1))
#}



############################################################################
## Multiple comparisons using Tukey's method (With the help of Vlad Kovtun)
##########################################################################

rtukey <- function(x,gr, ret.pval=F, conf.level=0.95){
if(!is.matrix(x)) x = toarray(x)
  xm <- cmat(x,gr)
  ngr <- ncol(xm)
  tgr <- table(gr)
  y <- nn <- NULL
  for(i in 2:ngr) {
    y = cbind( y, xm[,i:ngr]-xm[,i-1])
    nn = c(nn,1/tgr[i:ngr]+1/tgr[i-1]) 
  }
  ncy <- ncol(y) 
  nms <- as.character(unique(gr))
  nms <- outer(nms, nms, paste, sep = "-")
  nms <- dimnames(y)[[2]] <- nms[lower.tri(nms)]
  nms1 <- c(rbind(nms,paste("pv",nms,sep="")),"Rank") 
  nms2 <- c(rbind(nms,paste("Sign.",nms,sep="")),"Sign.","Rank") 
  MSE <- rmse(x,gr)
  df = sum(tgr -1) 
  # width <- qtukey(conf.level, ngr, df)*sqrt(outer(MSE/2,nn, "*"))
  yy = y/sqrt(outer(MSE/2,nn, "*"))
  absyy= abs(yy)
  generank = rank( -eval(parse(text=paste("pmax(",paste("absyy[,",1:ncy,"]",sep="",collapse=","),")",sep=""))))
  if(ret.pval) {
       qq <- sort(c( absyy[absyy> quantile(absyy,0.95)],
            quantile(absyy, (0:95)/100)))
       ptk <- ptukey(qq,ngr,df)
       qtk <-sqrt(-log(1-ptk/1.0001))
	tt <- approx(qq,qtk,absyy)$y
        ytukey= 1.0001*(1-exp(-array(tt,dim=dim(yy))^2))
        tt=cbind(yy,1-ytukey)
#        tt1=cbind(yy,1-ptukey(yy,ngr,df))
        tt= data.frame(tt[,c(rbind(1:ncy,ncy+1:ncy))],Rank=generank)
        names(tt) = nms1
  }
  else {
       sign <- abs(y) > qtukey(conf.level, ngr, df)*sqrt(outer(MSE/2,nn, "*"))
       tt <- data.frame( round(yy,6),array(c("NS","S")[1+sign],dim=dim(y))) 
       tt = cbind( tt[,c(rbind(1:ncy,ncy+1:ncy))],c("No","Yes")[1+(rmean(sign)>0)],generank)
       names(tt)=nms2
   }
   tt[sort.list(generank),]
}

############ DNA MICROARRAY GRAPH ######################
bplot <-  function(z,rid,cid,w=c(0,5,10,50,100,200),col=heat.colors(100)){ 
    if(missing(rid)) rid = rep(1,nrow(z))
    if(missing(cid)) cid = rep(1,ncol(z))
    zz= (z -min(z))
    zz = zz/max(zz)
    kk <- length(unique(rid))
    n <- nrow(zz)
    ss <- length(unique(cid))
    nc <- ncol(zz)
    sk <- max(c(15/ss, 2))
    sk2 <- max(c(12/kk, 2))
    ii <- sort.list(rid)
    jj <- sort.list(cid)
    mm <- rbind(c(0, rep(1, ss), 0), cbind(2, array(3, c(kk, 
        ss)), 3 + (1:kk)), c(0, rep(kk + 4, ss), 0))
    nf <- layout(mm, c(1, rep(sk, ss), 6), c(1, rep(2*sk2, kk), 
        1), TRUE)
    layout.show(nf)
    par(mar = c(0, 1, 0.5, 0))
    y <- table(cid)
    y <- cumsum(y) - y/2
    image(1:nc, 1, 1 + array((cid[jj]), c(nc, 1))%%2, zlim = c(0, 
        2), col = col, add = F, axes = F)
    text(y, rep(1, ss), paste("C", 1:ss, sep = ""))
    box()
    par(mar = c(1, 0.5, 1, 0))
    y <- rev(table(rid))
    y <- cumsum(y) - y/2
    image(1, 1:n, 1 + array(rev(rid[ii]), c(1, n))%%2, xlim = c(0.5, 
        2), zlim = c(0, 2), col = col, add = F, axes = F)
    text(rep(1.3, kk), y + 0.8, rev(LETTERS[1:kk]))
    box()
    zzz <- (t(as.matrix(zz)))[sort.list(cid), sort.list(rid)]
    zzz <- zzz[, ncol(zzz):1]
    par(mar = c(1, 1, 1, 0))
    image(1:nc, 1:ncol(zzz), zzz, xlab = "", ylab = "", add = F, 
        col = col, axes = F)
    box()
    par(mar = c(0, 2, 1, 1), cex = 0.5)
    for (i in 1:kk) {
        j <- rid == i
        y <- apply(as.matrix(zz[j, ]), 2, mean)
        y <- y/max(y)
        plot(1:nc, y, ylim = c(0, 1.01), type = "l", lty = 1, 
            las = 1, ylab = "", xlab = "", axes = F)
        text(1:nc, rep(-0.15, nc), labels = names(zz))
        text(rep(-0.05, 3), c(0, 0.5, 1), labels = c("0.0", "0.5", 
            "1.0"))
        box()
        title(paste(LETTERS[i], ": ", sum(j), " Genes"))
    }
    par(cex = 0.7)
    par(mar = c(0.7, 1, 0, 0))
    y <- seq(from = min(zzz), to = max(zzz), length = 100)
    dim(y) <- c(100, 1)
    image(c(y), 1, y, add = F, col = col, axes = F)
    ll <- round(y[seq(from = 10, to = 90, length = 9)], 1)
    box()
    text(ll, rep(1, 9), ll)
    par(mfrow=c(1,1))
}


##############
rgenes <- function(x,gg,p=100,n=20) {
par(mar=c(2,1,1,1))
if(sum(par()$mfrow)<=2) par(mfrow=c(2,2))
x.F <- rF(x,gg) 
x <-  x[sort.list(x.F[,2]),][1:p,]
i  <-rep(1:0,c(n,p-n)) 
x1=x[i==1,]
while(T) {
s=rep(-10^10,p)
for(j in (1:p)[!i]) { u <- rpca(rbind(x1,x[j,]))$scores[,1:2]
s[j]= rsq(t(u),gg)
}
i[ii <- sort.list(-s)[1]] <- 1
x1 <- x[i==1,]
u <- rpca(x1)$scores[,1:2]
u[,1] <- sign(u[1,1])*u[,1]
u[,2] <- sign(u[1,2])*u[,2]
plot(u,col=rep(unique(gg),table(gg)),pch=16,main=paste("Ngenes=",sum(i)))
plot(x[ii,],type='l', col=ii)
txt <- readline("Enter <Ret> to increase the n.of genes, 'q' to quit: ")
#if(txt == '-') i <- i-1 else i<-i+1
#if(i < 2) i <- 2
if(txt== 'q') break
}
}

ctukey <- function (x, gr, ret.pval = F, conf.level = 0.95) 
{ 
    if (!is.matrix(x)) 
        x = toarray(x) 
    xm <- cmat(x, gr) 
    ngr <- ncol(xm) 
    tgr <- table(gr) 
    y <- nn <- NULL 
    for (i in 2:ngr) { 
        y = cbind(y, xm[, i:ngr] - xm[, i - 1]) 
        nn = c(nn, 1/tgr[i:ngr] + 1/tgr[i - 1]) 
    } 
    ncy <- ncol(y) 
    nms <- as.character(unique(gr)) 
    nms <- outer(nms, nms, paste, sep = "-") 
    nms <- dimnames(y)[[2]] <- nms[lower.tri(nms)] 
    nms1 <- c(rbind(nms, paste("pv", nms, sep = "")), "Rank") 
    nms2 <- c(rbind(nms, paste("Sign.", nms, sep = "")), "Sign.", 
        "Rank") 
    MSE <- rmse(x, gr) 
    df = sum(tgr - 1) 
    yy = y/sqrt(outer(MSE/2, nn, "*"))#### 
    absyy = abs(yy) 
    generank = rank(-eval(parse(text = paste("pmax(", paste("absyy[,", 
        1:ncy, "]", sep = "", collapse = ","), ")", sep = "")))) 
    if (ret.pval) { 
        qq <- sort(c(absyy[absyy > quantile(absyy, 0.95)], quantile(absyy, 
            (0:95)/100))) 
        ptk <- ptukey(qq, ngr, df) 
        qtk <- sqrt(-log(1 - ptk/1.0001)) 
        tt <- approx(qq, qtk, absyy)$y 
        ytukey = 1.0001 * (1 - exp(-array(tt, dim = dim(yy))^2)) 
        tt = cbind(yy, 1 - ytukey) 
        tt = data.frame(tt[, c(rbind(1:ncy, ncy + 1:ncy))], Rank = generank) 
        names(tt) = nms1 
    } 
    else { 
        sign <- abs(y) > qtukey(conf.level, ngr, df) * sqrt(outer(MSE/2, 
            nn, "*")) 
        tt <- data.frame(round(yy, 6), array(c("NS", "S")[1 + 
            sign], dim = dim(y))) 
        tt = cbind(tt[, c(rbind(1:ncy, ncy + 1:ncy))], c("No", 
            "Yes")[1 + (rmean(sign) > 0)], generank) 
        names(tt) = nms2 
    } 
################################################# 
        yys<-t(rsort(absyy)) 
        plot(MSE^.5,yys[,ncol(yys)]^(.5),ylab="Tukey^0.5",pch=".") 
        abline(qtukey(conf.level,unique(table(gr)), df)^.5,0) 
        propsign <- qtukey(conf.level,unique(table(gr)), df)<yys[,ncol(yys)]
        u = smooth.spline(log(MSE),propsign,df=5)
        plot(exp(u$x)^0.5,u$y,type="l",xlab="MSE^0.5",ylab="Prop.Sign.")
        tt[sort.list(generank)[1:50], ] 
}

##############################################################################
#  This functions perform optimal power transformations.
#
#

second_der = function(x,method=c("kmeans","hclust","pam"),jrange=1:25,dd=2,w=1,prev=F,hc.method="ward.D") {
  ## x is an array,             ##  jrange n of clusters to be checked
  ## fun is an hclust object      ##  dd number of differences
  kmeans1 = function(x,k){c0=v0=10^20;for(i in 1:1000){v=kmeans(x,k); if(v$tot.withinss < c0){c0=v$tot.withinss;v0=v}} ;v0}
  pam1 <- function(x,k) list(cluster = pam(x,k,cluster.only=TRUE))
  
  if(is.function(method)) fun= method else if(is.character(method)) {
    me= substr(method,1,1) 
    if(me =="k") fun=kmeans1 else if(me=="p") fun=pam1 else if(me=="h") fun=hclust(dist(x),method=hc.method)
    else (return("Wrong Method"))
  }
  x=as.matrix(x)
  wss4 = function(x,y,w = rep(1, length(y))) sum(lm(x~-1+factor(y),weights = w)$resid^2*w)
  ### wss4 calculates within cluster sum of squares
  sm1 = NULL
  for(i in jrange) sm1[i]= if(i==1) sum(lm(x~1)$resid^2) else{ 
    if(me=="h") wss4(x,cutree(fun,i)) else wss4(x,fun(x,i)$cluster)}
  sm1=sm1[jrange]
  k = if(dd==1) sm1[-1] else -diff(sm1) 
  sm3=if(prev) -diff(k)/k[-length(k)]*100 else -diff(k)/k[-1]*100
  plot(jrange[c(-1,-length(k))], sm3,pch=16,col=2,type="b")
  list(number=jrange[c(-1,-length(k))] [sort.list(-sm3)], wss=sm1,dwss=k,ddwss=sm3)
}

transgap=function(z,alpha=0.5) {
  x=z[!is.na(z)]
  library("moments")
  signch = F
  ### Errors for negative values
  if(all(x<=0)) {x = -x; signch = T}
  mx=min(x)
  if(mx < 0) x= x-mx  else mx=0
  
  ### Extra functions gap and skew
  gap= function(x) if(any(x==0))  if(all(x>=0)| all(x<=0))
    min(abs(x)[x!=0])/sd(x[x!=0]) else 0 else 0
  skew=function(x) if(min(x)>=0)skewness(x[x>0]) else              if(max(x)<=0) skewness(x[x<0]) else skewness(x)
  p0=c(2,1,0.5,0.25,-0.25,-0.5,-1,-2)
  c0 = c(0.001,0.01,0.1,0.2,0.5,1,2,5,10,20,100,500,1000)
  y=NULL
  res=NULL
  if(min(x)==0) ad0=1 else ad0=0
  for(i in p0[1:4]) {
    u= (x^i); y=cbind(y,u)
    res=cbind(res,c(skew(u),gap(u),i)) }
  for(i in p0[-(1:4)]) {
    u= -(x+ad0)^i ; y=cbind(y,u)
    res=cbind(res,c(skew(1+u),gap(1+u),i)) }
  for(i in c0) {
    u= log(1+i*x) ; y=cbind(y,u)
    res=cbind(res,c(skew(u),gap(u),i)) }
  # alpha=0.75
  #browser()
  if(min(res[2,])>alpha) {alpha= min(res[2,]); cat("Warning there may be a gap at 0\n")}
  res[1,res[2,]>alpha]= res[1,res[2,]>alpha]+1000000
  i=which.min(abs(res[1,]))
  str=  if(i<=3) paste("x^",res[3,i],sep="") else
    if(i<=7) paste("-(x+",ad0,")^",res[3,i],sep="") else
      paste("log(1+x*",res[3,i],")",sep="")
  z[!is.na(z)] = y[,i]
  list( x=z,trans=str,SignChange=signch,ShiftNegative=mx)
}

trans2t = function(z,alphaplus=0.5,alphaminus=0.25) {
  i = z >=0
  j = z<=0
  t1 = transgap(z[i],alpha=alphaplus)
  t2 = transgap(-z[j],alpha=alphaminus)
  zp = z
  zp[i]=t1[[1]]
  zp[!i]=-t2[[1]][t2[[1]]>0]
  list(x=zp,trans=paste(t1[[2]]," x>0;  ",t2[[2]],"  x<0"))
}


rtar1 <- function(a,z,gg) {
x = sign(a[2])*(z-a[1])^a[2]
p = ncol(x)
n = nrow(x)
tgr = c(table(gg))
ngr = length(tgr)
i = rep(rep(0:1,ngr)[-1],c(rbind(p,tgr))[-1])
dim(i) =c(p,ngr)
im = t(t(i)/tgr)
xm = x%*%im
xr = x - xm%*%t(i)
r1 = cv ( sqrt((xs<-rsum(xr^2))/(p-ngr)))
r2 = mean(rsum(xr^3)^2/xs^3,na.rm=TRUE)
xs = log(0.01+xr^2%*%i)
sum(r1,r2,mean(diag(cor(xm,xs))^2))
}

rtar2 <- function(a,z,gg) {
x = log(z-a)
p = ncol(x)
n = nrow(x)
tgr = c(table(gg))
ngr = length(tgr)
i = rep(rep(0:1,ngr)[-1],c(rbind(p,tgr))[-1])
dim(i) =c(p,ngr)
im = t(t(i)/tgr)
xm = x%*%im
xr = x - xm%*%t(i)
r1 = cv ( sqrt((xs<-rsum(xr^2))/(p-ngr)))
r2 = mean(rsum(xr^3)^2/xs^3,na.rm=T)
xs = sqrt(xr^2%*%i) 
sum(r1,r2,mean(diag(cor(xm,xs))^2))
}


rtar0 <- function(a,b,z,gg) rtar1(c(a,b),z,gg)

rlog <- function(z,gg) 
optimize(rtar2,interval=c(-10^7,min(z)),z=z,gg=gg)$min
 
rpow <- function( z=z,gg=gg) {
b=0.5 
for(i in 1:5) { a=optimize( rtar0,c(-10^7,min(z)),b=b,z=z,gg=gg)$min
b= optimize( rtar0, c(-5,2), a= a,z=z,gg=gg)$min
}
c(a,b)
}

rpow = function( x,gg=gg,a= c(-30,0.1),method="multidim",k=40) {
if(substring(method,1,1)=="m") optim(a,rtar1,z=x,gg=gg)
else {
aa=a[1]
for(i in 1:k) { 
a[1]=optimize( rtar0,c(aa,min(z)),b=a[2],z=z,gg=gg)$min
a[2]= optimize( rtar0, c(-5,2), a= a[1],z=z,gg=gg)$min
}
}
return(a)
}



csum <- function(x,n=nrow(x),na.rm=T) {
  ik <- rep(1,n)
  if(na.rm) {
    x[is.na(x)] <- 0
    c(ik%*%x)
  } else  c(ik%*%x) 
}

#pv0=chisqt (t(gn24w),y4) 
chisqt = function(x=t(gn24w),y1) {
  n = length(y1)  
  x0 = (x==0)*1
  x1 = (x==1)*1
  x2 = (x==2)*1
  a0=cbind(csum(x0),csum(x1),csum(x2))
  o2 = cbind(csum(x0*y1),csum(x1*y1),csum(x2*y1))
  o2 = cbind(a0-o2,o2)
  b0 = c(n-sum(y1),sum(y1))
  ee= cbind(a0*b0[1],a0*b0[2])/n
  ee= (o2-ee)^2/ee
  df0 = 2- csum(t(is.na(ee)))/2
  ee[is.na(ee)]=0
  pv = 1 - pchisq(csum(t(ee)),df=df0)
  pv[df0==0] = 1
  pv
}

chisqt4 = function(x=t(gn24w),y) {
  n = length(y)
  xg = sort(unique(x)); nx = length(xg)
  yg = sort(unique(y))
  x0 = list();for(i in 1:nx) x0[[i]] = (x==xg[i])*1
  a0=csum(x0[[1]])
  for(i in 2:xg) a0=cbind(a0,csum(x0[[i]]))
  kk=(y4==1)
  o2 = cbind(csum(x0*kk),csum(x1*kk),csum(x2*kk))
  kk=(y4==2)
  o3 = cbind(csum(x0*kk),csum(x1*kk),csum(x2*kk))
  kk=(y4==3)
  o4 = cbind(csum(x0*kk),csum(x1*kk),csum(x2*kk))
  o2 = cbind(a0-o2-o3-o4,o2,o3,o4)
  b0 = c(table(y4))
  ee= cbind(a0*b0[1],a0*b0[2],a0*b0[3],a0*b0[4])/n
  ee= (o2-ee)^2/ee
  df0 = 6- 3*rsum(is.na(ee))/4
  ee[is.na(ee)]=0
  pv = 1 - pchisq(rsum(ee),df=df0)
  pv[df0==0] = 1
  pv
}

################   Functions for DNAMR package  ###############################
###########  DISCLIMER: These function have no guaranty of any kind that 
###########  they will perform any computations. Use them at your own risk. 
###############################################################################
